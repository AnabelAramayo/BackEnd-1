import dao.OdontologoDAOH2;
import model.Odontologo;
import service.OdontologoService;

import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception{
        OdontologoService odontologoService = new OdontologoService();
        BD.crearBD();
        Odontologo odonto1 = new Odontologo(986246855L, "Tony", "Stark");
        Odontologo odonto2 = new Odontologo(964762586L, "Chavo", "DelOcho");
        Odontologo odonto3 = new Odontologo(346974288L, "Super", "Man");
        Odontologo odonto4 = new Odontologo(798562472L, "Dark", "Vader");


        odontologoService.setOdontologoIDao(new OdontologoDAOH2());
        odontologoService.registrar(odonto1);
        odontologoService.registrar(odonto2);
        odontologoService.registrar(odonto3);
        odontologoService.registrar(odonto4);

        odontologoService.listar();
    }
}
