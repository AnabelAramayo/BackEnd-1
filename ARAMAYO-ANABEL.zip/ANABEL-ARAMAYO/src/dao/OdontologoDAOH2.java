package dao;

import model.Odontologo;

import org.apache.log4j.Logger;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class OdontologoDAOH2 implements IDao<Odontologo> {
    private static final Logger logger = Logger.getLogger(OdontologoDAOH2.class);
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    @Override
    public Odontologo registrar(Odontologo odontologo) {
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("INSERT INTO ODONTOLOGO (numeroMatricula, nombre, apellido) VALUES(?, ?, ?)", Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setLong(1,odontologo.getNumeroMatricula());
            preparedStatement.setString(2,odontologo.getApellido());
            preparedStatement.setString(3,odontologo.getNombre());

            preparedStatement.executeUpdate();
            ResultSet res = preparedStatement.getGeneratedKeys();
            if(res.next()){
                odontologo.setId(res.getLong(1));
            }

            logger.info("Creamos el odontólogo: " + odontologo.getId() + ". Se llama: " + odontologo.getNombre() + " " + odontologo.getApellido() + ", y su número de matrícula es: " + odontologo.getNumeroMatricula());

            preparedStatement.close();

        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return odontologo;
    }

    @Override
    public List<Odontologo> listar() {
        List<Odontologo> odontologos = new ArrayList<>();
        try {
            connection = getConnection();
            preparedStatement = connection.prepareStatement("SELECT * FROM odontologo");

            ResultSet result = preparedStatement.executeQuery();

            while (result.next()) {
                Long id = result.getLong("id");
                Long matricula = result.getLong("numeroMatricula");
                String nombre = result.getString("nombre");
                String apellido = result.getString("apellido");
                odontologos.add(new Odontologo(matricula, nombre, apellido));
                logger.info("ID: " + id + ". Apellido y Nombre: " + nombre + " " + apellido + ". Número de matrícula: " + matricula);
            }

            preparedStatement.close();

        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return odontologos;
    }

    public static Connection getConnection() throws Exception{
        return DriverManager.getConnection("jdbc:h2:~/test","sa","");
    }
}
