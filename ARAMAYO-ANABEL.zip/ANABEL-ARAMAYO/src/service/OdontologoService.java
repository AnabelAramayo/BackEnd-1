package service;

import dao.IDao;
import model.Odontologo;

import java.sql.SQLException;
import java.util.List;

public class OdontologoService {
    private IDao<Odontologo> odontologoIDao;

    public OdontologoService(IDao<Odontologo> odontologoIDao) {
        this.odontologoIDao = odontologoIDao;
    }

    public OdontologoService() {
    }

    public void setOdontologoIDao(IDao<Odontologo> odontologoIDao) {
        this.odontologoIDao = odontologoIDao;
    }

    public Odontologo registrar(Odontologo o) throws SQLException {
        return odontologoIDao.registrar(o);
    }

    public List<Odontologo> listar(){
        return odontologoIDao.listar();
    }
}
