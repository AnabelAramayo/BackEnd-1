package service;

import dao.IDao;
import dao.OdontologoDAOH2;
import model.Odontologo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OdontologoServiceTest {
    private IDao<Odontologo> odontologoIDaoTest = new OdontologoDAOH2();
    private OdontologoService odontologoServiceTest = new OdontologoService();

    @BeforeEach
    void setUp() throws Exception {
        Odontologo odonto1 = new Odontologo(986246855L, "Tony", "Stark");
        Odontologo odonto2 = new Odontologo(964762586L, "Chavo", "DelOcho");
        Odontologo odonto3 = new Odontologo(346974288L, "Super", "Man");
        Odontologo odonto4 = new Odontologo(798562472L, "Dark", "Vader");

        odontologoServiceTest.setOdontologoIDao(odontologoIDaoTest);
    }

    @Test
    void listar() {
        odontologoServiceTest.listar();
    }
}